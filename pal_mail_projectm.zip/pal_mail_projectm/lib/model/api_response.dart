class ApiResponse {
  Object? data;
  String? error;
}
