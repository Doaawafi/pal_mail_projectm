package com.example.pal_mail_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
